# Secure Login Challenge
This project addresses all the web vulnerabilities and implements login system in a secure way

**Web vulnerabilities addressed**
- Cross Site Forgery Request
- Clickjacking
- SQL/NoSQL/LDAP/XML Injection
- XSS Attack
- Response Manipulation
- Sensitive Information Disclosure
- Authentication Bypass
- Parameter Pollution & Mass Assignment
- Credentials Over Unencrypted Channel
- Missing Brute-Force Protection
- User Enumeration
- Throttling Requests
- Remote Code Execution



A secure Login is a very important aspect for a dynamic website. Develop a secure Login Module for your web application with encrypted user credentials and session management. Your code snippet should address all web vulnerabilities and should not give unauthorised access to the users without actual credentials

Note: You will only be allowed to submit once. Please submit all code once.

iT ADDRESSES ALL THE VULNERABILITIES, 
ALSO, DJANGO WAS USED FOR THE SAME
